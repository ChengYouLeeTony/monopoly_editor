goog.provide('Blockly.JavaScript.testBlocks');

goog.require('Blockly.JavaScript');

Blockly.JavaScript['test'] = function() {

};

Blockly.JavaScript['test_block'] = function() {

};